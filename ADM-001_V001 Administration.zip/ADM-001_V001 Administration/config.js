export const config = {apiKey:'A_COMPLETER',authDomain:'A_COMPLETER',projectId:'A_COMPLETER',appId:'A_COMPLETER'};
