export const config = {
  "apiKey": "AIzaSyBc0D6iIr0OchMTTKDFCJjINQkmcEf3Bxk",
  "authDomain": "adm-001-administration.firebaseapp.com",
  "projectId": "adm-001-administration",
  "storageBucket": "adm-001-administration.firebasestorage.app",
  "messagingSenderId": "337568488890",
  "appId": "1:337568488890:web:2a69377d1f007a8dab9183",
  "databaseURL": "https://adm-001-administration-default-rtdb.europe-west1.firebasedatabase.app/"
};
