// Navigation réseau prioritaire, limitée au point d’entrée Administration.
const ROOT = new URL('./', self.location.href);
self.addEventListener('install', event => event.waitUntil(self.skipWaiting()));
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', event => {
 const req = event.request, url = new URL(req.url);
 if (req.mode !== 'navigate' || url.origin !== ROOT.origin || !url.pathname.startsWith(ROOT.pathname)) return;
 const path = url.pathname.slice(ROOT.pathname.length);
 if (path !== '' && path !== 'index.html' && !/^index-V[0-9]{3,}\.html$/.test(path)) return;
 event.respondWith((async () => {
  const fresh = new URL(ROOT.href);
  fresh.searchParams.set('_boot', Date.now().toString());
  try { const response = await fetch(fresh.href, {cache:'no-store', credentials:'same-origin'}); if (response.ok) return response; } catch {}
  return new Response('<!doctype html><html lang="fr"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Administration</title><p>Connexion nécessaire pour ouvrir Administration.</p><button onclick="location.reload()">Réessayer</button></html>', {headers:{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store'}});
 })());
});
